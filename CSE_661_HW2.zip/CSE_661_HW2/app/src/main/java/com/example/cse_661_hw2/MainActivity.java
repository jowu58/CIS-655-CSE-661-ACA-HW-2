package com.example.cse_661_hw2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.Scanner;

class Register{
    static int s0 = 0;
    static int r1 = 0;
    static int r2 = 0;
    static int r3 = 0;
    static int r4 = 0;
    static int r5 = 0;
}

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_title);
    }

    public void Start(View view) {
        setContentView(R.layout.activity_main);
    }

    public void Run(View view) {
        System.out.println("Please enter code:");
        boolean exitFlag = false;
        while (!exitFlag) {
            // Scanner sc = new Scanner(System.in);
//            String input = sc.nextLine();
            String lowercase = input.toLowerCase(); // lower case string for instruction
            String[] tokens = lowercase.split("\\."); // break string into token
            String operation = tokens[0];
            System.out.println("Address: " + System.identityHashCode(input)); //Print memory address
            PrintBinary(tokens[0], tokens[1], tokens[2], tokens[3], Integer.parseInt(tokens[4])); //Print binary code
            switch (operation) { // switch case base on instruction operation
                case "add":
                    AddOperation(tokens[1], tokens[2], tokens[3], Integer.parseInt(tokens[4]));
                    break;
                case "sub":
                    SubOperation(tokens[1], tokens[2], tokens[3], Integer.parseInt(tokens[4]));
                    break;
                case "mul":
                    MulOperation(tokens[1], tokens[2], tokens[3], Integer.parseInt(tokens[4]));
                    break;
                case "div":
                    DivOperation(tokens[1], tokens[2], tokens[3], Integer.parseInt(tokens[4]));
                    break;
            }
/*            System.out.println("s0: " + Register.s0);
            System.out.println("r1: " + Register.r1);
            System.out.println("r2: " + Register.r2);
            System.out.println("r3: " + Register.r3);
            System.out.println("r4: " + Register.r4);
            System.out.println("r5: " + Register.r5);*/
/*            if (input.equals(""))
                exitFlag = true;*/

        }
    }

    private static void CheckSyntax(String syntax) {
        String[] tokens = syntax.split("\\.");
        if (tokens.length > 5) {
            System.out.println("Syntax error");
        }
        if (!tokens[0].equals("add") && !tokens[0].equals("sub") && !tokens[0].equals("mul") && !tokens[0].equals("div")){
            System.out.println("Syntax error with instruction code");
        }
        if (!tokens[1].equals("s0") && !tokens[1].equals("r1") && !tokens[1].equals("r2") &&
                !tokens[1].equals("r3") && !tokens[1].equals("r4") && !tokens[1].equals("r5")){
            System.out.println("Syntax error with first register");
        }
        if (!tokens[2].equals("s0") && !tokens[2].equals("r1") && !tokens[2].equals("r2") &&
                !tokens[2].equals("r3") && !tokens[2].equals("r4") && !tokens[2].equals("r5")){
            System.out.println("Syntax error with second register");
        }
        if (!tokens[3].equals("r1") && !tokens[3].equals("r2") && !tokens[3].equals("r3") &&
                !tokens[3].equals("r4") && !tokens[3].equals("r5")){
            System.out.println("Syntax error with destination register");
        }
        try {
            Integer.parseInt(tokens[4]);
        } catch(NumberFormatException e){
            System.out.println("Syntax error with immediate value");
        }
    }
}
